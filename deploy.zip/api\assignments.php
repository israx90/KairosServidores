<?php
// api/assignments.php - Assignment Management Logic
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        handleGet($pdo);
        break;
    case 'POST':
        if (isset($input['action']) && $input['action'] === 'bulk_assign') {
            // Future implementation for bulk
            echo json_encode(['success' => false, 'message' => 'Not implemented yet']);
        } else {
            handleCreateAssignment($pdo, $input);
        }
        break;
    case 'PUT':
        handleUpdateAssignment($pdo, $input);
        break;
    case 'DELETE':
        handleDeleteAssignment($pdo, $input);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid Request Method']);
        break;
}

function handleGet($pdo)
{
    if (isset($_GET['event_id'])) {
        // Get assignments for a specific event
        $stmt = $pdo->prepare("
            SELECT a.*, u.name as user_name, u.alias as user_alias, u.profile_pic, t.name as team_name 
            FROM assignments a
            JOIN users u ON a.user_id = u.id
            LEFT JOIN teams t ON a.team_id = t.id
            WHERE a.event_id = ?
        ");
        $stmt->execute([$_GET['event_id']]);
        $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($assignments);
    } elseif (isset($_GET['user_id'])) {
        // Get assignments for a specific user
        $stmt = $pdo->prepare("
            SELECT a.*, e.name as event_name, e.event_date, e.event_time, e.type 
            FROM assignments a
            JOIN events e ON a.event_id = e.id
            WHERE a.user_id = ?
            ORDER BY e.event_date ASC
        ");
        $stmt->execute([$_GET['user_id']]);
        $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($assignments);
    } else {
        echo json_encode(['success' => false, 'message' => 'Event ID or User ID required']);
    }
}

function handleCreateAssignment($pdo, $input)
{
    if (!isset($input['event_id']) || !isset($input['user_id']) || !isset($input['role'])) {
        echo json_encode(['success' => false, 'message' => 'Event, User, and Role required']);
        return;
    }

    $teamId = $input['team_id'] ?? null;

    try {
        $stmt = $pdo->prepare("INSERT INTO assignments (event_id, user_id, team_id, role, status) VALUES (?, ?, ?, ?, 'pending')");
        $stmt->execute([$input['event_id'], $input['user_id'], $teamId, $input['role']]);
        echo json_encode(['success' => true, 'message' => 'Assignment Created', 'id' => $pdo->lastInsertId()]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleUpdateAssignment($pdo, $input)
{
    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'Assignment ID required']);
        return;
    }

    $fields = [];
    $params = [];

    if (isset($input['status'])) {
        $fields[] = 'status = ?';
        $params[] = $input['status'];
    }
    if (isset($input['role'])) {
        $fields[] = 'role = ?';
        $params[] = $input['role'];
    }
    if (isset($input['team_id'])) {
        $fields[] = 'team_id = ?';
        $params[] = $input['team_id'];
    }

    if (empty($fields)) {
        echo json_encode(['success' => false, 'message' => 'No fields to update']);
        return;
    }

    $params[] = $input['id'];
    $sql = "UPDATE assignments SET " . implode(', ', $fields) . " WHERE id = ?";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['success' => true, 'message' => 'Assignment Updated']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleDeleteAssignment($pdo, $input)
{
    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'Assignment ID required']);
        return;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM assignments WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['success' => true, 'message' => 'Assignment Deleted']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>