<?php
// api/setup_admin.php
require_once 'config.php';

header('Content-Type: application/json');

$adminUser = 'ISRAX';
$adminAlias = 'ISRAX';
$adminPass = 'Poteto2023';
$adminEmail = 'admin@krs.com'; // Default email
$adminPhone = '74573450';

try {
    // Check if user exists (by name or alias)
    $stmt = $pdo->prepare("SELECT id FROM users WHERE name = ? OR alias = ?");
    $stmt->execute([$adminUser, $adminAlias]);

    if ($stmt->rowCount() > 0) {
        // Update existing user
        $hash = password_hash($adminPass, PASSWORD_DEFAULT);
        $update = $pdo->prepare("UPDATE users SET password_hash = ?, role = 'admin', alias = ?, phone = ?, is_temp_password = 0 WHERE name = ? OR alias = ?");
        $update->execute([$hash, $adminAlias, $adminPhone, $adminUser, $adminAlias]);
        echo json_encode(['success' => true, 'message' => 'Admin user updated.']);
    } else {
        // Create new user
        $hash = password_hash($adminPass, PASSWORD_DEFAULT);
        $insert = $pdo->prepare("INSERT INTO users (name, alias, email, phone, password_hash, role, is_temp_password) VALUES (?, ?, ?, ?, ?, 'admin', 0)");
        $insert->execute([$adminUser, $adminAlias, $adminEmail, $adminPhone, $hash]);
        echo json_encode(['success' => true, 'message' => 'Admin user created.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>