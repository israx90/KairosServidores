<?php
// api/month_summary.php - Monthly coverage summary
require_once 'config.php';

header('Content-Type: application/json');

$year  = isset($_GET['year'])  ? intval($_GET['year'])  : intval(date('Y'));
$month = isset($_GET['month']) ? intval($_GET['month']) : intval(date('m'));

// Pad month
$monthStr = str_pad($month, 2, '0', STR_PAD_LEFT);

try {
    $stmt = $pdo->prepare("
        SELECT 
            e.event_date,
            COUNT(DISTINCT e.id) as event_count,
            COUNT(DISTINCT a.id) as assigned_count
        FROM events e
        LEFT JOIN assignments a ON a.event_id = e.id
        WHERE e.event_date LIKE ?
        GROUP BY e.event_date
        ORDER BY e.event_date ASC
    ");
    $stmt->execute(["$year-$monthStr-%"]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($rows);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
