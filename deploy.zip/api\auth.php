<?php
// api/auth.php - Authentication Logic
require_once 'config.php';

// Get JSON input
$data = json_decode(file_get_contents("php://input"));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // LOGIN
    if (isset($data->action) && $data->action === 'login') {
        $username = $data->username ?? '';
        $password = $data->password ?? '';

        if (empty($username) || empty($password)) {
            jsonResponse(null, "Usuario y contraseña requeridos.", false);
        }

        try {
            // Find user by alias (ignoring spaces), name, OR phone
            // We use REPLACE(alias, ' ', '') to allow matching "JuanPerez" input against "Juan Perez" DB value
            $stmt = $pdo->prepare("SELECT * FROM users WHERE REPLACE(alias, ' ', '') = ? OR REPLACE(name, ' ', '') = ? OR phone = ? LIMIT 1");
            $stmt->execute([$username, $username, $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password_hash'])) {
                // Remove sensitive data
                unset($user['password_hash']);

                // Set Session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];

                jsonResponse($user, "Login exitoso.");
            } else {
                jsonResponse(null, "Credenciales incorrectas.", false);
            }
        } catch (PDOException $e) {
            jsonResponse(null, "Error en el servidor: " . $e->getMessage(), false);
        }
    }

    // CHANGE PASSWORD (User Self or Admin Reset)
    elseif (isset($data->action) && $data->action === 'change_password') {
        $userId = $data->user_id ?? 0;
        $currentPass = $data->current_password ?? '';
        $newPass = $data->new_password ?? '';

        // Check if Admin/Coordinator is resetting another user's password
        $isReset = false;
        if (isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'coordinator')) {
            if (isset($data->force_reset) && $data->force_reset === true) {
                $isReset = true;
            }
        }

        if (empty($userId) || empty($newPass)) {
            jsonResponse(null, "Faltan datos requeridos.", false);
        }

        try {
            // If NOT an admin reset, we must verify the current password
            if (!$isReset) {
                $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
                $stmt->execute([$userId]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$user) {
                    jsonResponse(null, "Usuario no encontrado.", false);
                }

                if (!password_verify($currentPass, $user['password_hash'])) {
                    jsonResponse(null, "La contraseña actual es incorrecta.", false);
                }
            }

            $newHash = password_hash($newPass, PASSWORD_DEFAULT);

            // If it's a reset, we might want to set is_temp_password = 1 again so they have to change it
            $isTemp = $isReset ? 1 : 0;

            $updateStmt = $pdo->prepare("UPDATE users SET password_hash = ?, is_temp_password = ? WHERE id = ?");
            $updateStmt->execute([$newHash, $isTemp, $userId]);

            jsonResponse(null, $isReset ? "Contraseña restablecida correctamente." : "Contraseña actualizada correctamente.");

        } catch (PDOException $e) {
            jsonResponse(null, "Error al actualizar contraseña.", false);
        }
    } else {
        jsonResponse(null, "Acción no válida.", false);
    }
} else {
    jsonResponse(null, "Método no permitido.", false);
}
?>