<?php
// api/upload_profile.php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(null, "Método no permitido.", false);
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    jsonResponse(null, "No autorizado.", false);
}

$userId = $_SESSION['user_id'];

if (!isset($_FILES['image'])) {
    jsonResponse(null, "No se recibió ninguna imagen.", false);
}

$file = $_FILES['image'];
$fileName = $file['name'];
$fileTmpName = $file['tmp_name'];
$fileSize = $file['size'];
$fileError = $file['error'];

// Validate Error
if ($fileError !== 0) {
    jsonResponse(null, "Error al subir el archivo. Código: " . $fileError, false);
}

// Validate Type
$fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
$allowed = ['jpg', 'jpeg', 'png', 'webp'];

if (!in_array($fileExt, $allowed)) {
    jsonResponse(null, "Solo se permiten archivos JPG, JPEG, PNG y WEBP.", false);
}

// Validate Size (Max 5MB)
if ($fileSize > 5 * 1024 * 1024) {
    jsonResponse(null, "El archivo es demasiado grande (Máx 5MB).", false);
}

// Generate unique name
$newFileName = "profile_" . $userId . "_" . uniqid() . "." . $fileExt;
$uploadDir = '../assets/uploads/';

// Ensure directory exists (just in case)
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$destination = $uploadDir . $newFileName;

if (move_uploaded_file($fileTmpName, $destination)) {
    // URL for frontend (relative to index.html)
    $publicUrl = 'assets/uploads/' . $newFileName;

    // Update Database
    try {
        $stmt = $pdo->prepare("UPDATE users SET profile_pic = ? WHERE id = ?");
        $stmt->execute([$publicUrl, $userId]);

        jsonResponse(['url' => $publicUrl], "Foto de perfil actualizada.");
    } catch (PDOException $e) {
        // cleanup if db fails
        unlink($destination);
        jsonResponse(null, "Error al actualizar la base de datos.", false);
    }
} else {
    jsonResponse(null, "Error al guardar el archivo en el servidor.", false);
}
?>