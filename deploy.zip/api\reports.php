<?php
// api/reports.php - Generate Reports Data
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $month = $_GET['month'] ?? date('m');
    $year = $_GET['year'] ?? date('Y');

    try {
        // Get all events and their assignments for the specified month
        $sql = "
            SELECT 
                e.id as event_id, e.name as event_name, e.event_date, e.event_time, e.type,
                a.id as assignment_id, a.role, a.status,
                u.name as user_name, u.alias as user_alias
            FROM events e
            LEFT JOIN assignments a ON e.id = a.event_id
            LEFT JOIN users u ON a.user_id = u.id
            WHERE MONTH(e.event_date) = ? AND YEAR(e.event_date) = ?
            ORDER BY e.event_date ASC, e.event_time ASC, a.role ASC
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$month, $year]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Group by event
        $report = [];
        foreach ($rows as $row) {
            $eventId = $row['event_id'];
            if (!isset($report[$eventId])) {
                $report[$eventId] = [
                    'id' => $eventId,
                    'name' => $row['event_name'],
                    'date' => $row['event_date'],
                    'time' => $row['event_time'],
                    'type' => $row['type'],
                    'assignments' => []
                ];
            }

            if ($row['assignment_id']) {
                $report[$eventId]['assignments'][] = [
                    'role' => $row['role'],
                    'user_name' => $row['user_name'],
                    'status' => $row['status']
                ];
            }
        }

        echo json_encode(array_values($report));

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid Request Method']);
}
?>