<?php
// api/events.php - Event Management Logic
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        handleGet($pdo);
        break;
    case 'POST':
        handleCreateEvent($pdo, $input);
        break;
    case 'PUT':
        handleUpdateEvent($pdo, $input);
        break;
    case 'DELETE':
        handleDeleteEvent($pdo, $input);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid Request Method']);
        break;
}

function handleGet($pdo)
{
    if (isset($_GET['id'])) {
        $stmt = $pdo->prepare("
            SELECT e.*, COALESCE(et.color, '#2979ff') as color
            FROM events e
            LEFT JOIN event_types et ON e.type = et.name
            WHERE e.id = ?
        ");
        $stmt->execute([$_GET['id']]);
        $event = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($event);
    } else {
        $sql = "
            SELECT e.*, COALESCE(et.color, '#2979ff') as color
            FROM events e
            LEFT JOIN event_types et ON e.type = et.name
            ORDER BY e.event_date ASC, e.event_time ASC
        ";
        $stmt = $pdo->query($sql);
        $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($events);
    }
}



function handleUpdateEvent($pdo, $input)
{
    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'Event ID required']);
        return;
    }

    $id = $input['id'];
    $fields = [];
    $params = [];

    if (isset($input['name'])) {
        $fields[] = 'name = ?';
        $params[] = $input['name'];
    }
    if (isset($input['event_date'])) {
        $fields[] = 'event_date = ?';
        $params[] = $input['event_date'];
    }
    if (isset($input['event_time'])) {
        $fields[] = 'event_time = ?';
        $params[] = $input['event_time'];
    }
    if (isset($input['type'])) {
        $fields[] = 'type = ?';
        $params[] = $input['type'];
    }

    if (empty($fields)) {
        echo json_encode(['success' => false, 'message' => 'No fields to update']);
        return;
    }

    $params[] = $id;
    $sql = "UPDATE events SET " . implode(', ', $fields) . " WHERE id = ?";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['success' => true, 'message' => 'Event Updated']);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            echo json_encode(['success' => false, 'message' => 'Duplicate event conflict.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }
}

function handleDeleteEvent($pdo, $input)
{
    if (isset($input['action']) && $input['action'] === 'batch_delete') {
        if (!isset($input['ids']) || !is_array($input['ids'])) {
            echo json_encode(['success' => false, 'message' => 'IDs array required']);
            return;
        }

        try {
            $ids = implode(',', array_map('intval', $input['ids']));
            $pdo->exec("DELETE FROM events WHERE id IN ($ids)");
            echo json_encode(['success' => true, 'message' => 'Events Deleted']);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
        return;
    }

    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'Event ID required']);
        return;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM events WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['success' => true, 'message' => 'Event Deleted']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleCreateEvent($pdo, $input)
{
    if (isset($input['action']) && $input['action'] === 'batch_create') {
        if (!isset($input['events']) || !is_array($input['events'])) {
            echo json_encode(['success' => false, 'message' => 'Events array required']);
            return;
        }

        $created = 0;
        $errors = 0;

        $stmt = $pdo->prepare("INSERT INTO events (name, event_date, event_time, type) VALUES (?, ?, ?, ?)");

        foreach ($input['events'] as $event) {
            try {
                $stmt->execute([$event['name'], $event['event_date'], $event['event_time'], $event['type']]);
                $created++;
            } catch (PDOException $e) {
                $errors++;
            }
        }

        echo json_encode(['success' => true, 'message' => "$created events created. $errors failed (duplicates)."]);
        return;
    }

    if (!isset($input['name']) || !isset($input['event_date']) || !isset($input['event_time']) || !isset($input['type'])) {
        echo json_encode(['success' => false, 'message' => 'All fields (name, date, time, type) are required']);
        return;
    }

    // Sanitize: treat date as plain calendar date string (no timezone conversion)
    $eventDate = preg_replace('/[^0-9\-]/', '', $input['event_date']);  // e.g. "2026-02-26"
    $eventTime = !empty($input['event_time']) ? $input['event_time'] : '00:00:00';
    $name = $input['name'];
    $type = $input['type'];

    try {
        $stmt = $pdo->prepare("INSERT INTO events (name, event_date, event_time, type) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $eventDate, $eventTime, $type]);
        echo json_encode(['success' => true, 'message' => 'Event Created', 'id' => $pdo->lastInsertId()]);
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            echo json_encode(['success' => false, 'message' => 'Duplicate event: An event with this name already exists at this time.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }
}
?>