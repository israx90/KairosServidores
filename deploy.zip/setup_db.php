<?php
// Script temporal para configurar la base de datos y el usuario admin
require_once 'api/config.php';

echo "<h1>Configuración de Base de Datos</h1>";
echo "<p>Base de datos detectada: <strong>" . DB_NAME . "</strong></p>";

try {
    // 1. Ejecutar el script SQL
    $sql = file_get_contents('if0_41055875_servidoreskrs.sql');
    if ($sql) {
        $pdo->exec($sql);
        echo "<p>✅ Tablas creadas correctamente desde el script SQL.</p>";
    } else {
        echo "<p>❌ No se encontró el archivo SQL.</p>";
    }

    // 2. Crear usuario ISRAX
    $alias = 'ISRAX';
    $password = 'Poteto2026';
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $role = 'admin';

    // Verificar si ya existe
    $stmt = $pdo->prepare("SELECT id FROM users WHERE alias = ?");
    $stmt->execute([$alias]);
    if ($stmt->fetch()) {
        // Actualizar
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, role = ?, is_temp_password = 0 WHERE alias = ?");
        $stmt->execute([$hash, $role, $alias]);
        echo "<p>✅ Usuario ISRAX actualizado.</p>";
    } else {
        // Insertar
        $stmt = $pdo->prepare("INSERT INTO users (alias, password_hash, role, is_temp_password) VALUES (?, ?, ?, 0)");
        $stmt->execute([$alias, $hash, $role]);
        echo "<p>✅ Usuario ISRAX creado.</p>";
    }
    
    // 3. Crear datos base (event_types, roles) si están vacíos
    $pdo->exec("INSERT IGNORE INTO event_types (name, color) VALUES ('Reunión Semanal', '#3B82F6'), ('Servicio Especial', '#8B5CF6'), ('Ensayo', '#10B981')");
    $pdo->exec("INSERT IGNORE INTO service_roles (name) VALUES ('Música'), ('Sonido'), ('Multimedia'), ('Ujier')");
    echo "<p>✅ Datos base (roles y tipos de evento) verificados.</p>";

    echo "<hr>";
    echo "<h3>¡Todo listo!</h3>";
    echo "<p>Ya puedes iniciar sesión en la aplicación. <a href='index.html'>Ir a la app</a></p>";
    
    // Auto-destrucción opcional (comentado para evitar problemas si se recarga)
    // unlink(__FILE__);
    
} catch (PDOException $e) {
    echo "<p>❌ Error de base de datos: " . $e->getMessage() . "</p>";
} catch (Exception $e) {
    echo "<p>❌ Error: " . $e->getMessage() . "</p>";
}
?>
