<?php
// api/reminders.php — Tomorrow's assignments for WhatsApp reminders
require_once 'config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(null, 'Method not allowed', false);
}

// Calculate tomorrow in the server timezone
$tomorrow = (new DateTime('tomorrow', new DateTimeZone('America/La_Paz')))->format('Y-m-d');

try {
    // Get all events for tomorrow
    $eventsStmt = $pdo->prepare("
        SELECT id, name, event_date, event_time, type
        FROM events
        WHERE event_date = ?
        ORDER BY event_time ASC
    ");
    $eventsStmt->execute([$tomorrow]);
    $events = $eventsStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($events)) {
        echo json_encode([]);
        exit;
    }

    // For each event, get assignments with user details
    $assignStmt = $pdo->prepare("
        SELECT a.id, a.role, a.status,
               u.id as user_id, u.name as user_name, u.alias, u.phone
        FROM assignments a
        JOIN users u ON a.user_id = u.id
        WHERE a.event_id = ?
        ORDER BY a.role ASC
    ");

    foreach ($events as &$event) {
        $assignStmt->execute([$event['id']]);
        $event['assignments'] = $assignStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    unset($event);

    // Only return events that have at least one assignment
    $events = array_values(array_filter($events, function ($e) {
        return count($e['assignments']) > 0;
    }));

    echo json_encode($events);

} catch (PDOException $e) {
    jsonResponse(null, 'Error: ' . $e->getMessage(), false);
}
?>