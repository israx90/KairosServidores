<?php
// api/service_roles.php

require_once 'config.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("php://input"));

switch ($method) {
    case 'GET':
        // List all roles
        try {
            $stmt = $pdo->query("SELECT * FROM service_roles ORDER BY name ASC");
            jsonResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
        } catch (PDOException $e) {
            jsonResponse(['error' => $e->getMessage()], "Error", false);
        }
        break;

    case 'POST':
        // Create or Update role
        if (!isset($data->name))
            jsonResponse(null, "Missing name", false);

        try {
            if (isset($data->id)) {
                // Update
                $stmt = $pdo->prepare("UPDATE service_roles SET name = ? WHERE id = ?");
                $stmt->execute([$data->name, $data->id]);
                jsonResponse(null, "Role updated");
            } else {
                // Create
                $stmt = $pdo->prepare("INSERT INTO service_roles (name) VALUES (?)");
                $stmt->execute([$data->name]);
                jsonResponse(['id' => $pdo->lastInsertId(), 'name' => $data->name], "Role created");
            }
        } catch (PDOException $e) {
            jsonResponse(null, "Error: " . $e->getMessage(), false);
        }
        break;

    case 'DELETE':
        // Delete role
        if (!isset($data->id))
            jsonResponse(null, "Missing ID", false);
        try {
            $stmt = $pdo->prepare("DELETE FROM service_roles WHERE id = ?");
            $stmt->execute([$data->id]);
            jsonResponse(null, "Role deleted");
        } catch (PDOException $e) {
            jsonResponse(null, "Error: " . $e->getMessage(), false);
        }
        break;

    default:
        jsonResponse(null, "Method not allowed", false);
}
?>