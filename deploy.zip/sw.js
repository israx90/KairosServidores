const CACHE_NAME = 'krs-cache-v1';
const ASSETS_TO_CACHE = [
    './',
    './index2.html',
    './css/style.css',
    './logo/logo.png',
    './assets/default-avatar.svg',
    // Third party
    'https://unpkg.com/@phosphor-icons/web',
    'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css',
    'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js'
];

self.addEventListener('install', (event) => {
    // Force immediate takeover
    self.skipWaiting();
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(ASSETS_TO_CACHE);
        })
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
    self.clients.claim();
});

// Cache First Strategy for assets, Network First for APIs
self.addEventListener('fetch', (event) => {
    const isApiCall = event.request.url.includes('/api/');
    
    if (isApiCall) {
        // Network First, fallback to cache (if any) or error
        event.respondWith(
            fetch(event.request)
            .catch(() => caches.match(event.request))
        );
    } else {
        // Cache First, fallback to network
        event.respondWith(
            caches.match(event.request)
            .then((response) => {
                if (response) return response;
                // Fetch and cache newly discovered assets dynamically (Stale-While-Revalidate pattern manually)
                return fetch(event.request).then(
                    (networkResponse) => {
                        // Don't cache if not a valid response
                        if(!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
                            return networkResponse;
                        }
                        const responseToCache = networkResponse.clone();
                        caches.open(CACHE_NAME)
                            .then((cache) => {
                                // Only cache GET requests
                                if(event.request.method === 'GET') {
                                    cache.put(event.request, responseToCache);
                                }
                            });
                        return networkResponse;
                    }
                );
            })
        );
    }
});
