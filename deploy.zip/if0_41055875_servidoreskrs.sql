-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: sql105.infinityfree.com
-- Tiempo de generación: 05-06-2026 a las 21:16:30
-- Versión del servidor: 11.4.12-MariaDB
-- Versión de PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_41055875_servidoreskrs`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `team_id` int(11) DEFAULT NULL,
  `role` varchar(50) NOT NULL,
  `status` enum('pending','confirmed','declined') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `assignments`
--

INSERT INTO `assignments` (`id`, `event_id`, `user_id`, `team_id`, `role`, `status`, `created_at`) VALUES
(1, 1, 3, NULL, 'Streaming', 'pending', '2026-02-17 18:56:34'),
(2, 36, 8, NULL, 'Streaming', 'pending', '2026-02-22 21:30:19'),
(3, 32, 8, NULL, 'Streaming', 'pending', '2026-02-22 21:30:39'),
(4, 41, 15, NULL, 'Streaming', 'pending', '2026-03-04 18:09:37'),
(6, 38, 10, NULL, 'Streaming', 'pending', '2026-03-04 22:26:15'),
(8, 43, 9, NULL, 'Streaming', 'pending', '2026-03-06 15:31:33'),
(9, 45, 9, NULL, 'Streaming', 'pending', '2026-03-06 15:31:45'),
(10, 40, 9, NULL, 'Streaming', 'pending', '2026-03-06 15:32:56'),
(11, 51, 9, NULL, 'Streaming', 'pending', '2026-03-06 15:33:34'),
(12, 36, 10, NULL, 'Streaming', 'pending', '2026-03-07 11:42:25'),
(13, 35, 8, NULL, 'Streaming', 'pending', '2026-03-15 15:41:12'),
(14, 39, 8, NULL, 'Streaming', 'pending', '2026-03-15 15:41:44'),
(15, 42, 13, NULL, 'Streaming', 'pending', '2026-03-31 00:07:54'),
(16, 44, 13, NULL, 'Streaming', 'pending', '2026-03-31 00:08:59'),
(17, 44, 8, NULL, 'Streaming', 'pending', '2026-04-09 23:59:53'),
(18, 43, 17, NULL, 'Streaming', 'pending', '2026-04-10 13:34:59'),
(19, 46, 17, NULL, 'Streaming', 'pending', '2026-04-10 13:35:11'),
(20, 63, 15, NULL, 'Streaming', 'pending', '2026-04-15 00:11:08'),
(21, 47, 15, NULL, 'Streaming', 'pending', '2026-04-17 01:26:48'),
(22, 64, 13, NULL, 'Streaming', 'pending', '2026-04-19 16:36:46'),
(23, 50, 13, NULL, 'Streaming', 'pending', '2026-04-20 15:14:29'),
(24, 48, 13, NULL, 'Streaming', 'pending', '2026-04-20 15:14:39'),
(25, 49, 10, NULL, 'Streaming', 'pending', '2026-04-22 15:29:33'),
(28, 66, 13, NULL, 'Streaming', 'pending', '2026-05-07 12:28:25'),
(27, 65, 14, NULL, 'Streaming', 'pending', '2026-04-26 13:43:55'),
(29, 67, 13, NULL, 'Streaming', 'pending', '2026-05-07 12:28:55'),
(31, 68, 13, NULL, 'Streaming', 'pending', '2026-05-11 01:06:54'),
(32, 69, 13, NULL, 'Streaming', 'pending', '2026-05-11 01:07:05'),
(33, 70, 15, NULL, 'Streaming', 'pending', '2026-06-03 19:24:13'),
(34, 85, 15, NULL, 'Streaming', 'pending', '2026-06-03 19:24:25'),
(35, 71, 15, NULL, 'Cámara 2', 'pending', '2026-06-03 19:24:36'),
(36, 86, 15, NULL, 'Streaming', 'pending', '2026-06-03 19:24:49'),
(37, 72, 13, NULL, 'Streaming', 'pending', '2026-06-04 20:42:46'),
(38, 73, 13, NULL, 'Streaming', 'pending', '2026-06-04 20:43:09'),
(39, 84, 13, NULL, 'Streaming', 'pending', '2026-06-04 20:43:40');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `key_name` varchar(50) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `type` varchar(100) NOT NULL DEFAULT 'General',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `events`
--

INSERT INTO `events` (`id`, `name`, `event_date`, `event_time`, `type`, `created_at`) VALUES
(36, 'Noche de Adoración', '2026-03-26', '19:00:00', 'Noche de Adoración', '2026-02-22 20:13:26'),
(35, 'Noche de Adoración', '2026-03-19', '19:00:00', 'Noche de Adoración', '2026-02-22 20:13:26'),
(34, 'Noche de Adoración', '2026-03-12', '19:00:00', 'Noche de Adoración', '2026-02-22 20:13:26'),
(33, 'Noche de Adoración', '2026-03-05', '19:00:00', 'Noche de Adoración', '2026-02-22 20:13:26'),
(32, 'Noche de Adoración', '2026-02-26', '19:00:00', 'Noche de Adoración', '2026-02-22 20:13:26'),
(37, 'Reunión General', '2026-03-01', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(38, 'Reunión General', '2026-03-08', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(39, 'Reunión General', '2026-03-15', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(40, 'Reunión General', '2026-03-22', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(41, 'Reunión General', '2026-03-29', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(42, 'Reunión General', '2026-04-05', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(43, 'Reunión General', '2026-04-12', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(44, 'Reunión General', '2026-04-19', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(45, 'Reunión General', '2026-04-26', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(46, 'Reunión General', '2026-05-03', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(47, 'Reunión General', '2026-05-10', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(48, 'Reunión General', '2026-05-17', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(49, 'Reunión General', '2026-05-24', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(50, 'Reunión General', '2026-05-31', '10:00:00', 'Reunión General', '2026-02-22 20:14:12'),
(51, 'Jovenes KRS', '2026-03-14', '18:30:00', 'Jovenes', '2026-03-04 18:00:06'),
(65, 'Noche de Adoración', '2026-04-30', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(64, 'Noche de Adoración', '2026-04-23', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(63, 'Noche de Adoración', '2026-04-16', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(62, 'Noche de Adoración', '2026-04-09', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(61, 'Noche de Adoración', '2026-04-02', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(66, 'Noche de Adoración', '2026-05-07', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(67, 'Noche de Adoración', '2026-05-14', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(68, 'Noche de Adoración', '2026-05-21', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(69, 'Noche de Adoración', '2026-05-28', '18:45:00', 'Noche de Adoración', '2026-03-04 18:22:26'),
(70, 'Reunión General', '2026-06-07', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(71, 'Reunión General', '2026-06-14', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(72, 'Reunión General', '2026-06-21', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(73, 'Reunión General', '2026-06-28', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(74, 'Reunión General', '2026-07-05', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(75, 'Reunión General', '2026-07-12', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(76, 'Reunión General', '2026-07-19', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(77, 'Reunión General', '2026-07-26', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(78, 'Reunión General', '2026-08-02', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(79, 'Reunión General', '2026-08-09', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(80, 'Reunión General', '2026-08-16', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(81, 'Reunión General', '2026-08-23', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(82, 'Reunión General', '2026-08-30', '10:00:00', 'Reunión General', '2026-06-03 19:09:43'),
(83, 'Noche de Adoración', '2026-06-04', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(84, 'Noche de Adoración', '2026-06-11', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(85, 'Noche de Adoración', '2026-06-18', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(86, 'Noche de Adoración', '2026-06-25', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(87, 'Noche de Adoración', '2026-07-02', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(88, 'Noche de Adoración', '2026-07-09', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(89, 'Noche de Adoración', '2026-07-16', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(90, 'Noche de Adoración', '2026-07-23', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(91, 'Noche de Adoración', '2026-07-30', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(92, 'Noche de Adoración', '2026-08-06', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(93, 'Noche de Adoración', '2026-08-13', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(94, 'Noche de Adoración', '2026-08-20', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26'),
(95, 'Noche de Adoración', '2026-08-27', '18:45:00', 'Noche de Adoración', '2026-06-03 19:10:26');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `event_types`
--

CREATE TABLE `event_types` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `color` varchar(20) DEFAULT '#ffffff',
  `text_color` varchar(20) DEFAULT '#000000'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `event_types`
--

INSERT INTO `event_types` (`id`, `name`, `color`, `text_color`) VALUES
(1, 'Reunión General', '#2196F3', '#FFFFFF'),
(2, 'Noche de Adoración', '#9C27B0', '#FFFFFF'),
(3, 'Jovenes', '#FFD700', '#000000'),
(4, 'Especial', '#E91E63', '#FFFFFF'),
(6, 'General', '#00BCD4', '#000000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','warning','success','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `service_roles`
--

CREATE TABLE `service_roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `service_roles`
--

INSERT INTO `service_roles` (`id`, `name`) VALUES
(1, 'Cámara 1'),
(2, 'Cámara 2'),
(3, 'Streaming');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `swaps`
--

CREATE TABLE `swaps` (
  `id` int(11) NOT NULL,
  `assignment_id` int(11) NOT NULL,
  `requester_id` int(11) NOT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `swaps`
--

INSERT INTO `swaps` (`id`, `assignment_id`, `requester_id`, `target_user_id`, `status`, `created_at`) VALUES
(1, 1, 3, NULL, 'pending', '2026-02-17 18:56:50');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `coordinator_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `teams`
--

INSERT INTO `teams` (`id`, `name`, `coordinator_id`, `created_at`) VALUES
(1, 'Streaming', NULL, '2026-02-16 18:51:41'),
(2, 'Cámaras', NULL, '2026-02-17 13:58:42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `team_members`
--

CREATE TABLE `team_members` (
  `id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `joined_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `team_members`
--

INSERT INTO `team_members` (`id`, `team_id`, `user_id`, `joined_at`) VALUES
(1, 1, 3, '2026-02-17 18:41:32'),
(2, 1, 12, '2026-02-22 20:31:09'),
(3, 1, 10, '2026-02-22 20:31:58'),
(4, 1, 13, '2026-03-04 18:01:17'),
(5, 1, 14, '2026-03-04 18:02:20'),
(6, 1, 9, '2026-03-04 18:03:09'),
(7, 1, 8, '2026-03-04 18:03:16'),
(8, 1, 15, '2026-03-04 18:05:35'),
(9, 1, 16, '2026-04-08 03:31:23'),
(10, 1, 17, '2026-04-10 13:29:13');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `alias` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','coordinator','server') DEFAULT 'server',
  `profile_pic` varchar(255) DEFAULT 'default_avatar.svg',
  `is_temp_password` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `alias`, `email`, `phone`, `birthdate`, `password_hash`, `role`, `profile_pic`, `is_temp_password`, `created_at`) VALUES
(7, 'Chris', 'Chris', NULL, '', NULL, '$2y$10$Chcb/UzimI4tpqeMGQjPSuv81YeL9N5YTukQdV3SUsSAGD7FPkhbS', 'admin', 'default_avatar.svg', 1, '2026-02-22 19:36:50'),
(8, 'Mate Arraya', 'Mate Arraya', 'arrayamateo@gmail.com', '63163802', '2005-01-15', '$2y$10$sldj0Q91Sz54oWXF0pKbGuhu0hG/bnghmakO1Qtib4AhnD4scmlK2', 'server', 'assets/uploads/profile_8_699e5740e3f57.png', 0, '2026-02-22 19:51:59'),
(9, 'Hibber', 'Hibber', 'hibberrons@gmail.com', '75278679', '1993-08-27', '$2y$10$MsBm7Lae8Rb6.3ZSljp2kej0i9FrLI5lhNcN7KcZ432JdO2/LZHEW', 'server', 'default_avatar.svg', 1, '2026-02-22 20:09:14'),
(5, 'Edson Israel Llanque Mamani', 'ISRAX', 'e.llanque.90@gmail.com', '74573450', '1990-10-31', '$2y$10$RizMVhElWUtAgwvPrcYHruCHTrg97b698ukLaBgsS7zhSxSKVsJXO', 'admin', 'assets/uploads/profile_5_699b5aa954f3c.png', 0, '2026-02-22 18:36:39'),
(10, 'Angela Fuentes Rodríguez', 'Angy', 'angelafuentes003@icloud.com', '77542693', '2005-01-13', '$2y$10$sayUJWJS44mq8GlO1GBReOJpHfTRu.vw47wpSMBcTdlwOiBmlKUwS', 'server', 'assets/uploads/profile_10_69a8795fa2ff0.png', 0, '2026-02-22 20:10:27'),
(16, 'Sisi', 'Sisi', NULL, '', NULL, '$2y$10$4ZkZ05DSrduDPlR4Dessn.uNtmhK84rb3uX2lIGXhFjQNDhkBmwe2', 'server', 'default_avatar.svg', 1, '2026-04-08 03:31:22'),
(13, 'Ana', 'Ana', 'isabel95.ana95@gmail.com', '68166236', '1995-02-02', '$2y$10$l7GNTH9cUBfZ7L2j.UiLBur6Ldl0l.FLOVMb6cZa/Jg5s3sLsF4h2', 'server', 'default_avatar.svg', 0, '2026-03-04 18:01:16'),
(14, 'Angel', 'Angel', 'axverastris@gmail.com', '72592683', '1991-01-13', '$2y$10$PcGKEGfMqWal7r8kjtleIu381MdJS04mARKQ13W.w3ygbocyYkJxy', 'server', 'default_avatar.svg', 0, '2026-03-04 18:02:20'),
(15, 'Yael Huasebe ', 'Chunbot', 'creative.creator2025@gmail.com', '65162230', '2002-07-07', '$2y$10$fB7cRXTJu66rCv5I6e4X/eG3JGB8y8xFylrk8smpxb1iU9/EREWCq', 'server', 'assets/uploads/profile_15_69a87bebbe48d.png', 0, '2026-03-04 18:05:34'),
(17, 'Alberto', 'Alberto', 'albertmaca72@gmail.com', '69735266', '2001-08-05', '$2y$10$L9JyGBeuhOHe.kcVk8dS2utOwH5tFWv/WD1ACXcFflmgVOEiST6la', 'server', 'default_avatar.svg', 0, '2026-04-10 13:29:13');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event_id` (`event_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `team_id` (`team_id`);

--
-- Indices de la tabla `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key_name` (`key_name`);

--
-- Indices de la tabla `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_event_time` (`event_date`,`event_time`,`name`);

--
-- Indices de la tabla `event_types`
--
ALTER TABLE `event_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `service_roles`
--
ALTER TABLE `service_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `swaps`
--
ALTER TABLE `swaps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignment_id` (`assignment_id`),
  ADD KEY `requester_id` (`requester_id`),
  ADD KEY `target_user_id` (`target_user_id`);

--
-- Indices de la tabla `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `coordinator_id` (`coordinator_id`);

--
-- Indices de la tabla `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_member` (`team_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de la tabla `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT de la tabla `event_types`
--
ALTER TABLE `event_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `service_roles`
--
ALTER TABLE `service_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `swaps`
--
ALTER TABLE `swaps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `team_members`
--
ALTER TABLE `team_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
