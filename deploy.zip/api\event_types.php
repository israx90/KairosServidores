<?php
// api/event_types.php - Event Type Management
require_once 'config.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$data = json_decode(file_get_contents("php://input"));

switch ($method) {
    case 'GET':
        // List all types
        try {
            $stmt = $pdo->query("SELECT * FROM event_types ORDER BY name ASC");
            jsonResponse($stmt->fetchAll(PDO::FETCH_ASSOC));
        } catch (PDOException $e) {
            jsonResponse(['error' => $e->getMessage()], "Error", false);
        }
        break;

    case 'POST':
        // Create or Update
        if (!isset($data->name))
            jsonResponse(null, "Missing name", false);

        $color = $data->color ?? '#ffffff';
        $textColor = $data->text_color ?? '#000000';

        try {
            if (isset($data->id)) {
                $stmt = $pdo->prepare("UPDATE event_types SET name = ?, color = ?, text_color = ? WHERE id = ?");
                $stmt->execute([$data->name, $color, $textColor, $data->id]);
                jsonResponse(null, "Type updated");
            } else {
                $stmt = $pdo->prepare("INSERT INTO event_types (name, color, text_color) VALUES (?, ?, ?)");
                $stmt->execute([$data->name, $color, $textColor]);
                jsonResponse(['id' => $pdo->lastInsertId(), 'name' => $data->name], "Type created");
            }
        } catch (PDOException $e) {
            jsonResponse(null, "Error: " . $e->getMessage(), false);
        }
        break;

    case 'DELETE':
        // Delete type
        if (!isset($data->id))
            jsonResponse(null, "Missing ID", false);
        try {
            $stmt = $pdo->prepare("DELETE FROM event_types WHERE id = ?");
            $stmt->execute([$data->id]);
            jsonResponse(null, "Type deleted");
        } catch (PDOException $e) {
            jsonResponse(null, "Error: " . $e->getMessage(), false);
        }
        break;

    default:
        jsonResponse(null, "Method not allowed", false);
}
?>