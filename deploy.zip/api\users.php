<?php
// api/users.php - User Management Logic
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        handleGet($pdo);
        break;
    case 'POST':
        handlePost($pdo, $input);
        break;
    case 'PUT':
        handlePut($pdo, $input);
        break;
    case 'DELETE':
        handleDelete($pdo, $input);
        break;
    default:
        echo json_encode(['message' => 'Invalid Request Method']);
        break;
}

function checkPermission($requiredRole = 'coordinator')
{
    if (!isset($_SESSION['role'])) {
        // Fallback for dev/testing if session checks fail, but ideally block
        // echo json_encode(['success' => false, 'message' => 'No autorizado']);
        // exit;
        return 'guest';
    }
    return $_SESSION['role'];
}

function handleGet($pdo)
{
    $role = checkPermission();

    if (isset($_GET['id'])) {
        $stmt = $pdo->prepare("
            SELECT u.id, u.name, u.alias, u.email, u.phone, u.role, u.profile_pic, u.birthdate,
                   tm.team_id, t.name as team_name
            FROM users u
            LEFT JOIN team_members tm ON tm.user_id = u.id
            LEFT JOIN teams t ON t.id = tm.team_id
            WHERE u.id = ?
        ");
        $stmt->execute([$_GET['id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($user);
    } else {
        $where = $role === 'coordinator' ? "WHERE u.role = 'server'" : "";
        $sql = "
            SELECT u.id, u.name, u.alias, u.email, u.phone, u.role, u.profile_pic, u.birthdate,
                   tm.team_id, t.name as team_name
            FROM users u
            LEFT JOIN team_members tm ON tm.user_id = u.id
            LEFT JOIN teams t ON t.id = tm.team_id
            $where
            ORDER BY u.name ASC
        ";
        $stmt = $pdo->query($sql);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($users);
    }
}

function handlePost($pdo, $input)
{
    $requesterRole = checkPermission();

    if ($requesterRole !== 'admin' && $requesterRole !== 'coordinator') {
        jsonResponse(null, "No tienes permiso para crear usuarios.", false);
        return;
    }

    // Create new user
    // User Request: Only Alias and Role required for creation.
    if (!isset($input['alias']) || empty($input['alias'])) {
        jsonResponse(null, "El Alias es obligatorio.", false);
        return;
    }

    $alias = $input['alias'];
    // Default Name to Alias if not provided
    $name = !empty($input['name']) ? $input['name'] : $alias;

    // Handle Email (Optional -> NULL)
    $email = !empty($input['email']) ? $input['email'] : null;

    $phone = $input['phone'] ?? '';
    $role = $input['role'] ?? 'server';

    // ENFORCE ROLE LIMITS
    if ($requesterRole === 'coordinator') {
        if ($role !== 'server') {
            jsonResponse(null, "Los coordinadores solo pueden crear Servidores.", false);
            return;
        }
    }

    // Generate temp password (or default)
    $tempPass = 'KRS2026';
    $passwordHash = password_hash($tempPass, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email, alias, phone, role, password_hash, is_temp_password) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([$name, $email, $alias, $phone, $role, $passwordHash]);
        echo json_encode(['success' => true, 'message' => 'Usuario Creado.', 'data' => ['alias' => $alias, 'password' => $tempPass]]);
    } catch (PDOException $e) {
        $msg = $e->getMessage();
        if ($e->getCode() == 23000) {
            if (strpos($msg, 'alias') !== false)
                $msg = "El Alias ya existe.";
            elseif (strpos($msg, 'email') !== false)
                $msg = "El Email ya existe.";
        }
        echo json_encode(['success' => false, 'message' => 'Error: ' . $msg]);
    }
}

function handlePut($pdo, $input)
{
    $requesterRole = checkPermission();

    // Update user
    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'User ID required']);
        return;
    }

    $id = $input['id'];

    // Check if editing self OR has permission
    $isSelf = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $id);

    if (!$isSelf && $requesterRole !== 'admin' && $requesterRole !== 'coordinator') {
        jsonResponse(null, "No tienes permiso.", false);
        return;
    }

    // Coordinator restriction on editing
    if ($requesterRole === 'coordinator' && !$isSelf) {
        // Verify target is a server
        $check = $pdo->prepare("SELECT role FROM users WHERE id = ?");
        $check->execute([$id]);
        $target = $check->fetch();
        if ($target && $target['role'] !== 'server') {
            jsonResponse(null, "No puedes editar este usuario.", false);
            return;
        }
    }

    $fields = [];
    $params = [];

    // Allow changing detailed fields
    if (isset($input['name'])) {
        $fields[] = 'name = ?';
        $params[] = $input['name'];
    }
    if (isset($input['alias'])) {
        $fields[] = 'alias = ?';
        $params[] = $input['alias'];
    }
    if (isset($input['email'])) {
        $fields[] = 'email = ?';
        $params[] = $input['email'];
    }
    if (isset($input['phone'])) {
        $fields[] = 'phone = ?';
        $params[] = $input['phone'];
    }
    if (isset($input['birthdate'])) {
        $fields[] = 'birthdate = ?';
        $params[] = $input['birthdate'];
    }

    // Only Admin can change Roles
    if (isset($input['role']) && $requesterRole === 'admin') {
        $fields[] = 'role = ?';
        $params[] = $input['role'];
    }

    if (empty($fields)) {
        echo json_encode(['success' => false, 'message' => 'No fields to update']);
        return;
    }

    $params[] = $id;
    $sql = "UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['success' => true, 'message' => 'User Updated']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleDelete($pdo, $input)
{
    $requesterRole = checkPermission();

    if ($requesterRole !== 'admin' && $requesterRole !== 'coordinator') {
        jsonResponse(null, "No autorizado.", false);
        return;
    }

    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'User ID required']);
        return;
    }

    // Coordinator check
    if ($requesterRole === 'coordinator') {
        $check = $pdo->prepare("SELECT role FROM users WHERE id = ?");
        $check->execute([$input['id']]);
        $target = $check->fetch();
        if ($target && $target['role'] !== 'server') {
            jsonResponse(null, "No puedes eliminar a este usuario.", false);
            return;
        }
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['success' => true, 'message' => 'Usuario Eliminado']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>