<?php
// api/swaps.php - Swap Management
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

if ($method === 'GET') {
    // Get swaps for a user or all swaps?
    // For now, let's get swaps relevant to the logged in user or all available
    // List swaps where:
    // 1. Status is pending
    // 2. Requester is NOT me (so I can accept)

    // We also need "My Requests" (swaps I requested)

    $userId = $_GET['user_id'] ?? null;

    if ($userId) {
        $stmt = $pdo->prepare("
            SELECT s.*, 
                e.name as event_name, e.event_date, e.event_time, 
                a.role, 
                u.name as requester_name
            FROM swaps s
            JOIN assignments a ON s.assignment_id = a.id
            JOIN events e ON a.event_id = e.id
            JOIN users u ON s.requester_id = u.id
            WHERE s.status = 'pending'
            ORDER BY e.event_date ASC
        ");
        $stmt->execute();
        $swaps = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($swaps);
    } else {
        echo json_encode([]);
    }
} elseif ($method === 'POST') {
    $action = $input['action'] ?? '';

    if ($action === 'request_swap') {
        // Create request
        $assignmentId = $input['assignment_id'];
        $requesterId = $input['requester_id']; // Should be verified with session

        try {
            // Check if already requested
            $check = $pdo->prepare("SELECT id FROM swaps WHERE assignment_id = ? AND status = 'pending'");
            $check->execute([$assignmentId]);
            if ($check->rowCount() > 0) {
                jsonResponse(null, "Ya existe una solicitud pendiente para este turno.", false);
            }

            $stmt = $pdo->prepare("INSERT INTO swaps (assignment_id, requester_id, status) VALUES (?, ?, 'pending')");
            $stmt->execute([$assignmentId, $requesterId]);
            jsonResponse(null, "Solicitud de cambio creada.");
        } catch (PDOException $e) {
            jsonResponse(null, "Error: " . $e->getMessage(), false);
        }
    } elseif ($action === 'accept_swap') {
        // Accept request
        $swapId = $input['swap_id'];
        $acceptorId = $input['acceptor_id']; // Me

        try {
            $pdo->beginTransaction();

            // 1. Get Swap Details
            $stmt = $pdo->prepare("SELECT * FROM swaps WHERE id = ? AND status = 'pending'");
            $stmt->execute([$swapId]);
            $swap = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$swap) {
                throw new Exception("Solicitud no encontrada o ya procesada.");
            }

            if ($swap['requester_id'] == $acceptorId) {
                throw new Exception("No puedes aceptar tu propia solicitud.");
            }

            // 2. Update Assignment User
            $updateAssign = $pdo->prepare("UPDATE assignments SET user_id = ? WHERE id = ?");
            $updateAssign->execute([$acceptorId, $swap['assignment_id']]);

            // 3. Close Swap Request
            $updateSwap = $pdo->prepare("UPDATE swaps SET status = 'approved', target_user_id = ? WHERE id = ?");
            $updateSwap->execute([$acceptorId, $swapId]);

            $pdo->commit();
            jsonResponse(null, "¡Cambio realizado con éxito!");

        } catch (Exception $e) {
            $pdo->rollBack();
            jsonResponse(null, "Error: " . $e->getMessage(), false);
        }
    } elseif ($action === 'reject_swap') {
        // Admin rejects: mark as rejected
        $swapId = $input['swap_id'] ?? null;
        if (!$swapId) {
            jsonResponse(null, "Swap ID requerido", false);
        }
        try {
            $stmt = $pdo->prepare("UPDATE swaps SET status = 'rejected' WHERE id = ?");
            $stmt->execute([$swapId]);
            jsonResponse(null, "Solicitud rechazada.");
        } catch (PDOException $e) {
            jsonResponse(null, "Error: " . $e->getMessage(), false);
        }
    }
}
?>