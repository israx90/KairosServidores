<?php
// Configuration for Servidor KRS

// Database Configuration
define('DB_SERVER', 'sql103.byethost7.com');
define('DB_USERNAME', 'b7_42110252');
define('DB_PASSWORD', '@Poteto2023');

// Session Start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Timezone
date_default_timezone_set('America/La_Paz'); // Adjust as needed

// Attempt to connect to MySQL database
define('DB_NAME', 'b7_42110252_servidoreskrs');

// Attempt to connect to MySQL database
try {
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8mb4");
} catch (PDOException $e) {
    // In production, log this error instead of showing it
    error_log("ERROR: Could not connect. " . $e->getMessage());
    die("Lo sentimos, hay un problema de conexión con la base de datos.");
}

// Function to respond with JSON
function jsonResponse($data, $message = "", $success = true)
{
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}
?>