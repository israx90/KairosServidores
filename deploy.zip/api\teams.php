<?php
// api/teams.php - Team Management Logic
require_once 'config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'GET':
        handleGet($pdo);
        break;
    case 'POST':
        // Check if adding a member or creating a team
        if (isset($input['action']) && $input['action'] === 'add_member') {
            handleAddMember($pdo, $input);
        } elseif (isset($input['action']) && $input['action'] === 'remove_member') {
            handleRemoveMember($pdo, $input);
        } else {
            handleCreateTeam($pdo, $input);
        }
        break;
    case 'PUT':
        handleUpdateTeam($pdo, $input);
        break;
    case 'DELETE':
        handleDeleteTeam($pdo, $input);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid Request Method']);
        break;
}

function handleGet($pdo)
{
    if (isset($_GET['id'])) {
        // Get specific team with members
        $stmt = $pdo->prepare("
            SELECT t.*, u.name as coordinator_name 
            FROM teams t 
            LEFT JOIN users u ON t.coordinator_id = u.id 
            WHERE t.id = ?
        ");
        $stmt->execute([$_GET['id']]);
        $team = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($team) {
            // Get members
            $stmtMembers = $pdo->prepare("
                SELECT u.id, u.name, u.role, u.profile_pic 
                FROM team_members tm 
                JOIN users u ON tm.user_id = u.id 
                WHERE tm.team_id = ?
            ");
            $stmtMembers->execute([$_GET['id']]);
            $team['members'] = $stmtMembers->fetchAll(PDO::FETCH_ASSOC);
        }

        echo json_encode($team);
    } else {
        // List all teams
        $stmt = $pdo->query("
            SELECT t.*, u.name as coordinator_name, 
            (SELECT COUNT(*) FROM team_members tm WHERE tm.team_id = t.id) as member_count 
            FROM teams t 
            LEFT JOIN users u ON t.coordinator_id = u.id
        ");
        $teams = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($teams);
    }
}

function handleCreateTeam($pdo, $input)
{
    if (!isset($input['name'])) {
        echo json_encode(['success' => false, 'message' => 'Team Name required']);
        return;
    }

    $name = $input['name'];
    $coordinatorId = $input['coordinator_id'] ?? null;

    try {
        $stmt = $pdo->prepare("INSERT INTO teams (name, coordinator_id) VALUES (?, ?)");
        $stmt->execute([$name, $coordinatorId]);
        echo json_encode(['success' => true, 'message' => 'Team Created', 'id' => $pdo->lastInsertId()]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleUpdateTeam($pdo, $input)
{
    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'Team ID required']);
        return;
    }

    $id = $input['id'];
    $fields = [];
    $params = [];

    if (isset($input['name'])) {
        $fields[] = 'name = ?';
        $params[] = $input['name'];
    }
    if (isset($input['coordinator_id'])) {
        $fields[] = 'coordinator_id = ?';
        $params[] = $input['coordinator_id'];
    }

    if (empty($fields)) {
        echo json_encode(['success' => false, 'message' => 'No fields to update']);
        return;
    }

    $params[] = $id;
    $sql = "UPDATE teams SET " . implode(', ', $fields) . " WHERE id = ?";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['success' => true, 'message' => 'Team Updated']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleDeleteTeam($pdo, $input)
{
    if (!isset($input['id'])) {
        echo json_encode(['success' => false, 'message' => 'Team ID required']);
        return;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM teams WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['success' => true, 'message' => 'Team Deleted']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

function handleAddMember($pdo, $input)
{
    if (!isset($input['team_id']) || !isset($input['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Team ID and User ID required']);
        return;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO team_members (team_id, user_id) VALUES (?, ?)");
        $stmt->execute([$input['team_id'], $input['user_id']]);
        echo json_encode(['success' => true, 'message' => 'Member Added to Team']);
    } catch (PDOException $e) {
        // Check for duplicate entry
        if ($e->getCode() == 23000) {
            echo json_encode(['success' => false, 'message' => 'User is already in this team']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }
}

function handleRemoveMember($pdo, $input)
{
    if (!isset($input['team_id']) || !isset($input['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Team ID and User ID required']);
        return;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM team_members WHERE team_id = ? AND user_id = ?");
        $stmt->execute([$input['team_id'], $input['user_id']]);
        echo json_encode(['success' => true, 'message' => 'Member Removed from Team']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>