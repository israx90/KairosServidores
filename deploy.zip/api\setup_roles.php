<?php
// api/setup_roles.php

require_once 'config.php';

echo "<h2>Setting up Service Roles...</h2>";

try {
    // defined roles table
    $sql = "CREATE TABLE IF NOT EXISTS service_roles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $pdo->exec($sql);
    echo "Table 'service_roles' created or already exists.<br>";

    // Default roles to seed
    $defaults = [
        'Cámara 1',
        'Cámara 2',
        'Streaming',
        'Pantalla',
        'Sonido',
        'Comunidad',
        'Fotografía',
        'Luces',
        'Dirección'
    ];

    $stmt = $pdo->prepare("INSERT IGNORE INTO service_roles (name) VALUES (?)");

    foreach ($defaults as $role) {
        $stmt->execute([$role]);
        echo "Seeded role: $role <br>";
    }

    echo "<h3>Setup Complete!</h3>";

} catch (PDOException $e) {
    die("DB Error: " . $e->getMessage());
}
?>