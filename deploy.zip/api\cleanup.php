<?php
// api/cleanup.php
// Limpia recordatorios caducados y datos que ya no sirven
require_once 'config.php';

function autoCleanup($pdo) {
    try {
        // Borrar recordatorios que ya pasaron la fecha de ejecución hace más de 7 días
        $stmt1 = $pdo->prepare("DELETE FROM reminders WHERE scheduled_time < DATE_SUB(NOW(), INTERVAL 7 DAY) AND status = 'sent'");
        $stmt1->execute();
        $deletedReminders = $stmt1->rowCount();

        // Podrías limpiar Swaps cancelados o expirados muy viejos
        $stmt2 = $pdo->prepare("DELETE FROM swaps WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY) AND (status = 'cancelled' OR status = 'approved')");
        $stmt2->execute();
        $deletedSwaps = $stmt2->rowCount();

        // Opcional: Logs de auditoria o sesiones antiguas si existieran

        return ['reminders' => $deletedReminders, 'swaps' => $deletedSwaps];
    } catch (PDOException $e) {
        // Silently fail or log it
        error_log("Cleanup error: " . $e->getMessage());
        return null;
    }
}

// Permitir llamada externa (vía URL/Fetch) o interna (includer)
if (basename($_SERVER['PHP_SELF']) == 'cleanup.php') {
    $res = autoCleanup($pdo);
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'cleaned' => $res]);
}
?>
